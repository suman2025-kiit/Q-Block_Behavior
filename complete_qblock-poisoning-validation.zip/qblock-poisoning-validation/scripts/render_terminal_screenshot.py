"""Render a terminal-style JPEG from the actual text output."""

from __future__ import annotations

import argparse
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont


def load_font(size: int):
    candidates = [
        "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf",
        "/usr/share/fonts/truetype/liberation2/LiberationMono-Regular.ttf",
    ]
    for candidate in candidates:
        if Path(candidate).exists():
            return ImageFont.truetype(candidate, size)
    return ImageFont.load_default()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    lines = args.input.read_text(encoding="utf-8").splitlines()
    font = load_font(24)
    title_font = load_font(22)
    width = 1840
    line_height = 34
    top = 86
    height = top + line_height * len(lines) + 48
    image = Image.new("RGB", (width, height), "#101010")
    draw = ImageDraw.Draw(image)
    draw.rounded_rectangle(
        (18, 18, width - 18, height - 18),
        18,
        fill="#080808",
        outline="#707070",
        width=2,
    )
    draw.rectangle((18, 18, width - 18, 68), fill="#303030")
    for index, color in enumerate(("#ff5f57", "#febc2e", "#28c840")):
        x = 48 + index * 30
        draw.ellipse((x, 34, x + 16, 50), fill=color)
    draw.text(
        (width // 2 - 210, 31),
        "qblock-poisoning — validation run",
        font=title_font,
        fill="#f0f0f0",
    )
    for index, line in enumerate(lines):
        draw.text(
            (48, top + index * line_height),
            line,
            font=font,
            fill="#eeeeee",
        )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    image.save(args.output, "JPEG", quality=94, subsampling=0)


if __name__ == "__main__":
    main()
