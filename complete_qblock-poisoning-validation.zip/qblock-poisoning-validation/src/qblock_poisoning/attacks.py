"""Synthetic update-level poisoning attacks for reproducible validation."""

from __future__ import annotations

import numpy as np


def poison_update(
    update: np.ndarray,
    attack: str,
    rng: np.random.Generator,
    *,
    sign_scale: float,
    gaussian_std_multiplier: float,
    model_replacement_scale: float,
) -> np.ndarray:
    if attack == "label_flipping":
        # Update-level proxy for training on inverted binary labels.
        return -0.85 * update + rng.normal(0.0, 0.12, size=update.shape)
    if attack == "sign_flipping":
        return sign_scale * update
    if attack == "gaussian_noise":
        scale = max(float(np.std(update)), 1e-3) * gaussian_std_multiplier
        return update + rng.normal(0.0, scale, size=update.shape)
    if attack == "model_replacement":
        return model_replacement_scale * update
    raise ValueError(f"unsupported attack: {attack}")
