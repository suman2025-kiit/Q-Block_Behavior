"""Core detector implementing the manuscript's consistency, risk, and trust rules."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence

import numpy as np


@dataclass(frozen=True)
class DetectorConfig:
    trust_threshold: float = 0.70
    reliability_eta: float = 0.80
    epsilon: float = 1e-12
    omega_magnitude: float = 0.50
    omega_direction: float = 0.50
    alpha_fidelity: float = 0.20
    beta_validation: float = 0.20
    gamma_reliability: float = 0.15
    delta_consistency: float = 0.25
    lambda_poisoning: float = 0.35

    def validate(self) -> None:
        if not 0.0 <= self.trust_threshold <= 1.0:
            raise ValueError("trust_threshold must be in [0, 1]")
        if not 0.0 <= self.reliability_eta <= 1.0:
            raise ValueError("reliability_eta must be in [0, 1]")
        if self.epsilon <= 0.0:
            raise ValueError("epsilon must be positive")
        if min(
            self.omega_magnitude,
            self.omega_direction,
            self.alpha_fidelity,
            self.beta_validation,
            self.gamma_reliability,
            self.delta_consistency,
            self.lambda_poisoning,
        ) < 0.0:
            raise ValueError("all detector coefficients must be non-negative")
        if not np.isclose(self.omega_magnitude + self.omega_direction, 1.0):
            raise ValueError("poisoning weights must sum to one")


@dataclass(frozen=True)
class DeviceDecision:
    device_id: int
    authenticated: bool
    fidelity: float
    reliability: float
    consistency: float
    magnitude_deviation: float
    poisoning_risk: float
    trust: float
    accepted: bool


@dataclass(frozen=True)
class RoundResult:
    reference_update: np.ndarray
    aggregate_update: np.ndarray | None
    decisions: tuple[DeviceDecision, ...]


def _as_vector(values: Sequence[float], size: int, name: str) -> np.ndarray:
    array = np.asarray(values, dtype=float)
    if array.shape != (size,):
        raise ValueError(f"{name} must have shape ({size},), received {array.shape}")
    if not np.all(np.isfinite(array)):
        raise ValueError(f"{name} contains a non-finite value")
    return array


def cosine_similarity(left: np.ndarray, right: np.ndarray, epsilon: float) -> float:
    denominator = float(np.linalg.norm(left) * np.linalg.norm(right) + epsilon)
    return float(np.clip(np.dot(left, right) / denominator, -1.0, 1.0))


def evaluate_updates(
    updates: np.ndarray,
    fidelity: Sequence[float],
    validation: Sequence[int | bool],
    previous_reliability: Sequence[float],
    sample_counts: Sequence[int] | None = None,
    config: DetectorConfig | None = None,
) -> RoundResult:
    """Evaluate one round and return per-device decisions plus trusted aggregate."""
    cfg = config or DetectorConfig()
    cfg.validate()
    updates = np.asarray(updates, dtype=float)
    if updates.ndim != 2 or updates.shape[0] == 0 or updates.shape[1] == 0:
        raise ValueError("updates must be a non-empty matrix [devices, parameters]")
    if not np.all(np.isfinite(updates)):
        raise ValueError("updates contain a non-finite value")

    devices = updates.shape[0]
    fidelity_array = _as_vector(fidelity, devices, "fidelity")
    validation_array = _as_vector(validation, devices, "validation")
    reliability_array = _as_vector(previous_reliability, devices, "previous_reliability")
    if np.any((fidelity_array < 0.0) | (fidelity_array > 1.0)):
        raise ValueError("fidelity must be in [0, 1]")
    if np.any((validation_array != 0.0) & (validation_array != 1.0)):
        raise ValueError("validation flags must be binary")
    if np.any((reliability_array < 0.0) | (reliability_array > 1.0)):
        raise ValueError("reliability must be in [0, 1]")

    authenticated = validation_array.astype(bool)
    if not np.any(authenticated):
        decisions = tuple(
            DeviceDecision(i, False, float(fidelity_array[i]), 0.0, 0.0, 1.0, 1.0, 0.0, False)
            for i in range(devices)
        )
        return RoundResult(np.zeros(updates.shape[1]), None, decisions)

    # Two-pass rule: collect authenticated updates first, then form the reference.
    reference = np.median(updates[authenticated], axis=0)
    reference_norm = float(np.linalg.norm(reference))
    decisions_list: list[DeviceDecision] = []

    for device_id, update in enumerate(updates):
        valid = bool(authenticated[device_id])
        reliability = cfg.reliability_eta * reliability_array[device_id] + (
            1.0 - cfg.reliability_eta
        ) * float(valid)
        if valid:
            cosine = cosine_similarity(update, reference, cfg.epsilon)
            consistency = float(np.clip((1.0 + cosine) / 2.0, 0.0, 1.0))
            magnitude = float(
                np.linalg.norm(update - reference) / (reference_norm + cfg.epsilon)
            )
            direction = (1.0 - cosine) / 2.0
            risk = float(
                np.clip(
                    cfg.omega_magnitude * magnitude
                    + cfg.omega_direction * direction,
                    0.0,
                    1.0,
                )
            )
            raw_trust = (
                cfg.alpha_fidelity * fidelity_array[device_id]
                + cfg.beta_validation
                + cfg.gamma_reliability * reliability
                + cfg.delta_consistency * consistency
                - cfg.lambda_poisoning * risk
            )
            trust = float(np.clip(raw_trust, 0.0, 1.0))
        else:
            consistency, magnitude, risk, trust = 0.0, 1.0, 1.0, 0.0
        accepted = valid and trust >= cfg.trust_threshold
        decisions_list.append(
            DeviceDecision(
                device_id,
                valid,
                float(fidelity_array[device_id]),
                float(reliability),
                consistency,
                magnitude,
                risk,
                trust,
                accepted,
            )
        )

    accepted_mask = np.asarray([item.accepted for item in decisions_list])
    aggregate: np.ndarray | None = None
    if np.any(accepted_mask):
        if sample_counts is None:
            counts = np.ones(devices, dtype=float)
        else:
            counts = _as_vector(sample_counts, devices, "sample_counts")
            if np.any(counts <= 0.0):
                raise ValueError("sample_counts must be positive")
        trust = np.asarray([item.trust for item in decisions_list])
        weights = trust[accepted_mask] * counts[accepted_mask]
        aggregate = np.average(updates[accepted_mask], axis=0, weights=weights)

    return RoundResult(reference, aggregate, tuple(decisions_list))
