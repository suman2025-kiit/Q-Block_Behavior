"""Coordinated synthetic validation corresponding to the manuscript's Algorithm 5."""

from __future__ import annotations

import csv
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np

from .attacks import poison_update
from .audit import chained_commitment
from .core import DetectorConfig, evaluate_updates


@dataclass
class Counts:
    tp: int = 0
    tn: int = 0
    fp: int = 0
    fn: int = 0

    def update(self, malicious: bool, quarantined: bool) -> None:
        if malicious and quarantined:
            self.tp += 1
        elif malicious:
            self.fn += 1
        elif quarantined:
            self.fp += 1
        else:
            self.tn += 1

    def metrics(self) -> tuple[float, float, float]:
        dr = 100.0 * self.tp / max(self.tp + self.fn, 1)
        fpr = 100.0 * self.fp / max(self.fp + self.tn, 1)
        asr = 100.0 * self.fn / max(self.tp + self.fn, 1)
        return dr, fpr, asr


def load_config(path: Path) -> dict[str, Any]:
    with path.open(encoding="utf-8") as handle:
        return json.load(handle)


def detector_config(raw: dict[str, Any]) -> DetectorConfig:
    poisoning = raw["poisoning_weights"]
    trust = raw["trust_weights"]
    return DetectorConfig(
        trust_threshold=raw["trust_threshold"],
        reliability_eta=raw["reliability_eta"],
        epsilon=raw["epsilon"],
        omega_magnitude=poisoning["magnitude"],
        omega_direction=poisoning["direction"],
        alpha_fidelity=trust["fidelity"],
        beta_validation=trust["validation"],
        gamma_reliability=trust["reliability"],
        delta_consistency=trust["consistency"],
        lambda_poisoning=trust["poisoning_penalty"],
    )


def generate_round(
    raw: dict[str, Any], attack: str, rng: np.random.Generator
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    devices = int(raw["num_devices"])
    dimension = int(raw["update_dimension"])
    malicious_count = int(np.ceil(raw["malicious_ratio"] * devices))
    malicious_ids = rng.choice(devices, size=malicious_count, replace=False)
    malicious = np.zeros(devices, dtype=bool)
    malicious[malicious_ids] = True

    shared_direction = rng.normal(0.0, 1.0, size=dimension)
    shared_direction /= np.linalg.norm(shared_direction)
    updates = shared_direction + rng.normal(0.0, 0.055, size=(devices, dimension))
    params = raw["attack_parameters"]
    for device_id in malicious_ids:
        updates[device_id] = poison_update(
            updates[device_id],
            attack,
            rng,
            sign_scale=params["sign_scale"],
            gaussian_std_multiplier=params["gaussian_std_multiplier"],
            model_replacement_scale=params["model_replacement_scale"],
        )

    fidelity = np.clip(rng.normal(0.96, 0.012, devices), 0.0, 1.0)
    validation = np.ones(devices, dtype=int)
    sample_counts = rng.integers(100, 501, size=devices)
    return updates, fidelity, validation, sample_counts, malicious


def run_experiment(raw: dict[str, Any], output_dir: Path) -> dict[str, Any]:
    output_dir.mkdir(parents=True, exist_ok=True)
    cfg = detector_config(raw)
    device_rows: list[dict[str, Any]] = []
    round_rows: list[dict[str, Any]] = []
    attack_counts = {name: Counts() for name in raw["attacks"]}
    previous_hash = "0" * 64

    for attack_index, attack in enumerate(raw["attacks"]):
        for seed in raw["seeds"]:
            rng = np.random.default_rng(int(seed) + 10000 * attack_index)
            reliability = np.full(raw["num_devices"], 0.95, dtype=float)
            for round_id in range(1, int(raw["rounds"]) + 1):
                updates, fidelity, validation, sample_counts, malicious = generate_round(
                    raw, attack, rng
                )
                result = evaluate_updates(
                    updates, fidelity, validation, reliability, sample_counts, cfg
                )
                reliability = np.asarray([d.reliability for d in result.decisions])
                counts = Counts()
                for decision in result.decisions:
                    is_malicious = bool(malicious[decision.device_id])
                    quarantined = not decision.accepted
                    counts.update(is_malicious, quarantined)
                    attack_counts[attack].update(is_malicious, quarantined)
                    device_rows.append(
                        {
                            "attack": attack,
                            "seed": seed,
                            "round": round_id,
                            "device_id": decision.device_id,
                            "malicious": int(is_malicious),
                            "authenticated": int(decision.authenticated),
                            "fidelity": f"{decision.fidelity:.6f}",
                            "reliability": f"{decision.reliability:.6f}",
                            "consistency": f"{decision.consistency:.6f}",
                            "magnitude_deviation": f"{decision.magnitude_deviation:.6f}",
                            "poisoning_risk": f"{decision.poisoning_risk:.6f}",
                            "trust": f"{decision.trust:.6f}",
                            "decision": "ACCEPT" if decision.accepted else "QUARANTINE",
                        }
                    )
                dr, fpr, asr = counts.metrics()
                payload = {
                    "attack": attack,
                    "seed": int(seed),
                    "round": round_id,
                    "accepted": sum(d.accepted for d in result.decisions),
                    "aggregate_present": result.aggregate_update is not None,
                }
                previous_hash = chained_commitment(payload, previous_hash)
                round_rows.append(
                    {
                        **payload,
                        "tp": counts.tp,
                        "tn": counts.tn,
                        "fp": counts.fp,
                        "fn": counts.fn,
                        "detection_rate_percent": f"{dr:.3f}",
                        "false_positive_rate_percent": f"{fpr:.3f}",
                        "update_level_asr_percent": f"{asr:.3f}",
                        "audit_commitment_sha3_256": previous_hash,
                    }
                )

    summary_rows = []
    overall = Counts()
    for attack, counts in attack_counts.items():
        dr, fpr, asr = counts.metrics()
        summary_rows.append(
            {
                "attack": attack,
                "tp": counts.tp,
                "tn": counts.tn,
                "fp": counts.fp,
                "fn": counts.fn,
                "detection_rate_percent": f"{dr:.3f}",
                "false_positive_rate_percent": f"{fpr:.3f}",
                "update_level_asr_percent": f"{asr:.3f}",
            }
        )
        overall.tp += counts.tp
        overall.tn += counts.tn
        overall.fp += counts.fp
        overall.fn += counts.fn

    _write_csv(output_dir / "device_decisions.csv", device_rows)
    _write_csv(output_dir / "round_metrics.csv", round_rows)
    _write_csv(output_dir / "attack_summary.csv", summary_rows)
    dr, fpr, asr = overall.metrics()
    return {
        "summary": summary_rows,
        "overall": {"counts": overall, "dr": dr, "fpr": fpr, "asr": asr},
        "final_hash": previous_hash,
        "decisions": len(device_rows),
        "rounds": len(round_rows),
    }


def _write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        raise ValueError(f"cannot write empty CSV: {path}")
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
