"""Deterministic, chained audit commitments for round results."""

from __future__ import annotations

import hashlib
import json
from typing import Any


def chained_commitment(payload: dict[str, Any], previous_hash: str) -> str:
    envelope = {"payload": payload, "previous_hash": previous_hash}
    canonical = json.dumps(envelope, sort_keys=True, separators=(",", ":"), allow_nan=False)
    return hashlib.sha3_256(canonical.encode("utf-8")).hexdigest()
