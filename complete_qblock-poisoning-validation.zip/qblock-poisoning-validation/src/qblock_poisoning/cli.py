"""Command-line interface."""

from __future__ import annotations

import argparse
import sys
from contextlib import redirect_stdout
from pathlib import Path

from .simulation import load_config, run_experiment


class Tee:
    def __init__(self, *streams):
        self.streams = streams

    def write(self, data: str) -> int:
        for stream in self.streams:
            stream.write(data)
        return len(data)

    def flush(self) -> None:
        for stream in self.streams:
            stream.flush()


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Validate Q-Block poisoning detection")
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, default=Path("outputs"))
    return parser


def print_report(raw, result) -> None:
    print("Q-BLOCK_BEHAVIOR | POISONING DETECTION VALIDATION")
    print("=" * 71)
    print("DEMONSTRATION: synthetic local updates; not manuscript test results")
    print(
        f"devices={raw['num_devices']}  malicious={raw['malicious_ratio']:.0%}  "
        f"rounds={raw['rounds']}  seeds={raw['seeds']}  tau_T={raw['trust_threshold']:.2f}"
    )
    print("-" * 71)
    print(f"{'ATTACK':<20} {'DR (%)':>10} {'FPR (%)':>10} {'ASR (%)':>10} {'TP/FP/FN':>16}")
    for row in result["summary"]:
        triple = f"{row['tp']}/{row['fp']}/{row['fn']}"
        print(
            f"{row['attack']:<20} {row['detection_rate_percent']:>10} "
            f"{row['false_positive_rate_percent']:>10} "
            f"{row['update_level_asr_percent']:>10} {triple:>16}"
        )
    overall = result["overall"]
    print("-" * 71)
    print(
        f"OVERALL              {overall['dr']:10.3f} {overall['fpr']:10.3f} "
        f"{overall['asr']:10.3f}"
    )
    print(f"evaluated decisions : {result['decisions']}")
    print(f"evaluated rounds    : {result['rounds']}")
    print(f"final audit hash    : {result['final_hash']}")
    print("CSV evidence        : device_decisions.csv, round_metrics.csv,")
    print("                      attack_summary.csv")
    print("ASR definition      : malicious updates accepted / malicious updates")
    print("STATUS              : VALIDATION COMPLETED")


def main() -> None:
    args = build_parser().parse_args()
    raw = load_config(args.config)
    result = run_experiment(raw, args.output_dir)
    report_path = args.output_dir / "sample_run.txt"
    with report_path.open("w", encoding="utf-8") as report:
        with redirect_stdout(Tee(sys.stdout, report)):
            print_report(raw, result)


if __name__ == "__main__":
    main()
