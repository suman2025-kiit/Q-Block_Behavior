# Dataset Folder

Place the TON_IoT network-flow CSV file here:

```text
data/Train_Test_Network.csv
```

The dataset should be downloaded from:

https://research.unsw.edu.au/projects/toniot-datasets

Do not commit the raw dataset if its license or distribution policy does not permit redistribution.

