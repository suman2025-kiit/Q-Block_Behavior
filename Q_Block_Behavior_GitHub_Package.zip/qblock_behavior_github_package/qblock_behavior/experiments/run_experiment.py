"""Command-line experiment runner for Q-Block_Behavior."""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import yaml

from qblock_behavior.core.blockchain import LedgerValidator
from qblock_behavior.core.data import load_toniot, make_synthetic_toniot, non_iid_partitions, prepare_features, stratified_sample
from qblock_behavior.core.federated import run_federated_round
from qblock_behavior.core.metrics import classification_report_dict
from qblock_behavior.core.quantum import VQCAnomalyModel


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run Q-Block_Behavior simulation")
    parser.add_argument("--config", default="config/default.yaml", help="Path to YAML configuration")
    parser.add_argument("--synthetic", action="store_true", help="Run with synthetic data instead of TON_IoT")
    parser.add_argument("--rounds", type=int, default=None, help="Override number of federated rounds")
    return parser.parse_args()


def load_config(path: str | Path) -> dict:
    with open(path, "r", encoding="utf-8") as handle:
        return yaml.safe_load(handle)


def main() -> None:
    args = parse_args()
    cfg = load_config(args.config)
    ds_cfg = cfg["dataset"]
    if args.synthetic:
        df = make_synthetic_toniot(n=ds_cfg.get("sample_size", 20000), seed=ds_cfg.get("seed", 42))
    else:
        df = load_toniot(ds_cfg["path"], label_column=ds_cfg.get("label_column", "label"))
        df = stratified_sample(df, ds_cfg.get("label_column", "label"), ds_cfg.get("sample_size", 20000), ds_cfg.get("seed", 42))

    prepared = prepare_features(
        df,
        label_column=ds_cfg.get("label_column", "label"),
        drop_columns=ds_cfg.get("drop_columns", []),
        pca_components=cfg["preprocessing"].get("pca_components", 16),
        quantum_components=cfg["preprocessing"].get("quantum_components", 4),
        seed=ds_cfg.get("seed", 42),
    )

    model = VQCAnomalyModel(learning_rate=cfg["federated"].get("learning_rate", 0.01), seed=ds_cfg.get("seed", 42))
    model.fit(prepared.quantum_train, prepared.y_train, epochs=20)
    scores = model.predict_proba(prepared.quantum_test)
    preds = (scores >= 0.5).astype(int)
    cls = classification_report_dict(prepared.y_test, preds, scores)

    partitions = non_iid_partitions(
        prepared.y_train,
        clients=cfg["federated"].get("clients", 20),
        alpha=cfg["federated"].get("dirichlet_alpha", 0.5),
        seed=ds_cfg.get("seed", 42),
    )

    clients = cfg["federated"].get("clients", 20)
    malicious_count = max(1, int(clients * cfg["federated"].get("malicious_fraction", 0.2)))
    malicious_clients = set(range(malicious_count))
    rounds = args.rounds or cfg["federated"].get("rounds", 30)
    validator = LedgerValidator()
    round_summaries = []
    for round_id in range(1, rounds + 1):
        _, summary = run_federated_round(
            round_id=round_id,
            x=prepared.x_train,
            y=prepared.y_train,
            partitions=partitions,
            malicious_clients=malicious_clients,
            validator=validator,
            tau_trust=cfg["trust"].get("tau_trust", 0.70),
            seed=ds_cfg.get("seed", 42) + round_id,
        )
        round_summaries.append(summary)

    accepted_mean = float(np.mean([r.accepted_updates for r in round_summaries]))
    trust_mean = float(np.mean([r.mean_trust for r in round_summaries]))
    print("Q-Block_Behavior Simulation Summary")
    print("-----------------------------------")
    print(f"Records used: {len(df)}")
    print(f"Clients: {clients}")
    print(f"Rounds: {rounds}")
    print(f"Detection rate: {cls['detection_rate']:.4f}")
    print(f"False-positive rate: {cls['false_positive_rate']:.4f}")
    print(f"Accuracy: {cls['accuracy']:.4f}")
    print(f"F1 score: {cls['f1']:.4f}")
    if "auc" in cls:
        print(f"AUC: {cls['auc']:.4f}")
    print(f"Mean accepted updates per round: {accepted_mean:.2f}")
    print(f"Mean adaptive trust: {trust_mean:.4f}")
    print(f"Layer-1 latency for {cfg['ledger']['devices_for_latency']} devices: {cfg['ledger']['layer1_anchor_ms']} ms")
    print(f"Layer-2/App-chain latency for {cfg['ledger']['devices_for_latency']} devices: {cfg['ledger']['layer2_batch_ms']} ms")


if __name__ == "__main__":
    main()
