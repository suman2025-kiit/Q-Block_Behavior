"""Q-Block_Behavior simulation package."""

__version__ = "0.1.0"

