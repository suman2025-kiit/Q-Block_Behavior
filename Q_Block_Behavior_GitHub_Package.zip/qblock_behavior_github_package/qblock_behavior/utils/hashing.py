"""Hashing helpers for off-chain artifacts and ledger commitments."""

from __future__ import annotations

import hashlib
import json
from typing import Any


def canonical_json(value: Any) -> bytes:
    """Serialize a value deterministically for hashing."""
    return json.dumps(value, sort_keys=True, separators=(",", ":")).encode("utf-8")


def keccak256_like(value: Any) -> str:
    """Return a SHA3-256 digest compatible with Keccak-style commitment use."""
    return hashlib.sha3_256(canonical_json(value)).hexdigest()

