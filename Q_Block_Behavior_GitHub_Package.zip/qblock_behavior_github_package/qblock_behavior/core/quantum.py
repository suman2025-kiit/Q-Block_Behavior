"""Quantum feature-map interface and VQC-style anomaly scoring."""

from __future__ import annotations

import numpy as np


def zz_feature_embedding(x: np.ndarray, reps: int = 2) -> np.ndarray:
    """Deterministic ZZ feature-map inspired embedding for four selected features.

    This fallback keeps the public artifact runnable without a quantum runtime.
    Replace this function with Qiskit ZZFeatureMap circuits when Qiskit execution
    is required.
    """
    x = np.asarray(x, dtype=float)
    features = [np.sin(np.pi * x), np.cos(np.pi * x)]
    for _ in range(reps):
        interactions = []
        for i in range(x.shape[1]):
            j = (i + 1) % x.shape[1]
            interactions.append(np.sin(np.pi * x[:, i] * x[:, j]))
        features.append(np.stack(interactions, axis=1))
    return np.concatenate(features, axis=1)


class VQCAnomalyModel:
    """Small logistic classifier used as a VQC-compatible simulation stand-in."""

    def __init__(self, learning_rate: float = 0.01, seed: int = 42) -> None:
        self.learning_rate = learning_rate
        self.rng = np.random.default_rng(seed)
        self.weights: np.ndarray | None = None
        self.bias = 0.0

    def fit(self, x: np.ndarray, y: np.ndarray, epochs: int = 20) -> "VQCAnomalyModel":
        phi = zz_feature_embedding(x)
        if self.weights is None:
            self.weights = self.rng.normal(0.0, 0.05, phi.shape[1])
        y = y.astype(float)
        for _ in range(epochs):
            logits = phi @ self.weights + self.bias
            pred = 1.0 / (1.0 + np.exp(-logits))
            error = pred - y
            self.weights -= self.learning_rate * (phi.T @ error / len(y))
            self.bias -= self.learning_rate * float(np.mean(error))
        return self

    def predict_proba(self, x: np.ndarray) -> np.ndarray:
        if self.weights is None:
            raise RuntimeError("Model is not fitted")
        phi = zz_feature_embedding(x)
        logits = phi @ self.weights + self.bias
        return 1.0 / (1.0 + np.exp(-logits))

    def predict(self, x: np.ndarray, threshold: float = 0.5) -> np.ndarray:
        return (self.predict_proba(x) >= threshold).astype(int)


def ghz_reference_fidelity(executed_state: np.ndarray) -> float:
    """Return a normalized fidelity-like score against a four-qubit GHZ reference."""
    state = np.asarray(executed_state, dtype=float)
    if state.ndim != 1:
        state = state.ravel()
    if np.linalg.norm(state) == 0:
        return 0.0
    state = state / np.linalg.norm(state)
    reference = np.zeros_like(state)
    reference[0] = 1 / np.sqrt(2)
    reference[-1] = 1 / np.sqrt(2)
    return float(np.clip(np.abs(np.vdot(reference, state)) ** 2, 0.0, 1.0))

