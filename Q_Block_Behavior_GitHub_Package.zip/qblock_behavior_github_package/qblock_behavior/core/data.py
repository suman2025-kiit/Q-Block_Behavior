"""Dataset loading, preprocessing, and non-IID partitioning."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.decomposition import PCA
from sklearn.impute import SimpleImputer
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import MinMaxScaler, OneHotEncoder


@dataclass
class PreparedData:
    x_train: np.ndarray
    x_test: np.ndarray
    y_train: np.ndarray
    y_test: np.ndarray
    quantum_train: np.ndarray
    quantum_test: np.ndarray
    pca: PCA


def load_toniot(path: str | Path, label_column: str = "label") -> pd.DataFrame:
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Dataset not found: {path}")
    df = pd.read_csv(path)
    if label_column not in df.columns:
        raise ValueError(f"Label column '{label_column}' not found in dataset")
    return df


def make_synthetic_toniot(n: int = 2000, seed: int = 42) -> pd.DataFrame:
    """Generate a small synthetic network-flow-like dataset for smoke tests."""
    rng = np.random.default_rng(seed)
    benign = int(n * 0.65)
    malicious = n - benign
    labels = np.array([0] * benign + [1] * malicious)
    rng.shuffle(labels)
    frame = pd.DataFrame(
        {
            "duration": rng.gamma(2.0 + labels, 1.5),
            "src_bytes": rng.normal(120 + 80 * labels, 30, n).clip(0),
            "dst_bytes": rng.normal(90 + 50 * labels, 25, n).clip(0),
            "conn_count": rng.poisson(3 + 4 * labels, n),
            "proto": rng.choice(["tcp", "udp", "icmp"], n),
            "service": rng.choice(["dns", "http", "ssl", "other"], n),
            "label": labels,
        }
    )
    return frame


def stratified_sample(df: pd.DataFrame, label_column: str, sample_size: int, seed: int) -> pd.DataFrame:
    if sample_size <= 0 or sample_size >= len(df):
        return df.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    _, sample = train_test_split(
        df,
        test_size=sample_size,
        stratify=df[label_column],
        random_state=seed,
    )
    return sample.reset_index(drop=True)


def prepare_features(
    df: pd.DataFrame,
    label_column: str = "label",
    drop_columns: Iterable[str] | None = None,
    pca_components: int = 16,
    quantum_components: int = 4,
    seed: int = 42,
) -> PreparedData:
    drop_columns = set(drop_columns or [])
    df = df.drop(columns=[c for c in drop_columns if c in df.columns], errors="ignore")
    y = df[label_column].astype(int).to_numpy()
    x = df.drop(columns=[label_column])
    numeric_cols = x.select_dtypes(include=["number", "bool"]).columns.tolist()
    categorical_cols = [c for c in x.columns if c not in numeric_cols]

    numeric_pipe = Pipeline(
        steps=[
            ("imputer", SimpleImputer(strategy="median")),
            ("scaler", MinMaxScaler()),
        ]
    )
    categorical_pipe = Pipeline(
        steps=[
            ("imputer", SimpleImputer(strategy="most_frequent")),
            ("onehot", OneHotEncoder(handle_unknown="ignore", sparse_output=False)),
        ]
    )
    transformer = ColumnTransformer(
        transformers=[
            ("num", numeric_pipe, numeric_cols),
            ("cat", categorical_pipe, categorical_cols),
        ],
        remainder="drop",
    )

    x_train_raw, x_test_raw, y_train, y_test = train_test_split(
        x, y, test_size=0.1, stratify=y, random_state=seed
    )
    x_train_full = transformer.fit_transform(x_train_raw)
    x_test_full = transformer.transform(x_test_raw)
    max_components = min(pca_components, x_train_full.shape[1], x_train_full.shape[0])
    pca = PCA(n_components=max_components, random_state=seed)
    x_train = pca.fit_transform(x_train_full)
    x_test = pca.transform(x_test_full)
    scaler = MinMaxScaler()
    x_train = scaler.fit_transform(x_train)
    x_test = scaler.transform(x_test)
    q = min(quantum_components, x_train.shape[1])
    return PreparedData(
        x_train=x_train,
        x_test=x_test,
        y_train=y_train,
        y_test=y_test,
        quantum_train=x_train[:, :q],
        quantum_test=x_test[:, :q],
        pca=pca,
    )


def non_iid_partitions(y: np.ndarray, clients: int, alpha: float, seed: int) -> list[np.ndarray]:
    """Create non-IID client indices using class-wise Dirichlet allocation."""
    rng = np.random.default_rng(seed)
    partitions: list[list[int]] = [[] for _ in range(clients)]
    for cls in np.unique(y):
        idx = np.where(y == cls)[0]
        rng.shuffle(idx)
        proportions = rng.dirichlet(np.repeat(alpha, clients))
        cut_points = (np.cumsum(proportions) * len(idx)).astype(int)[:-1]
        for client_id, split in enumerate(np.split(idx, cut_points)):
            partitions[client_id].extend(split.tolist())
    return [np.array(sorted(p), dtype=int) for p in partitions]

