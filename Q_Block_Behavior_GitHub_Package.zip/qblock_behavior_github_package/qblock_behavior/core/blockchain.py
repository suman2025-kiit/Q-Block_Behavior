"""Smart-contract-style validation for identity and update provenance."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

from qblock_behavior.utils.hashing import keccak256_like


@dataclass
class UpdateEnvelope:
    device_id: str
    did: str
    vc_id: str
    signature: str
    nonce: int
    model_version: int
    update_hash: str
    payload_hash: str


@dataclass
class ValidationResult:
    accepted: bool
    reason: str
    commitment: str


class LedgerValidator:
    """Local validator mirroring smart-contract checks used in the simulation."""

    def __init__(self, revoked_credentials: Iterable[str] | None = None) -> None:
        self.revoked_credentials = set(revoked_credentials or [])
        self.used_nonces: set[tuple[str, int]] = set()

    def verify(self, envelope: UpdateEnvelope, payload: dict) -> ValidationResult:
        if not envelope.did.startswith("did:"):
            return self._reject("invalid_did", envelope, payload)
        if envelope.vc_id in self.revoked_credentials:
            return self._reject("revoked_credential", envelope, payload)
        nonce_key = (envelope.device_id, envelope.nonce)
        if nonce_key in self.used_nonces:
            return self._reject("replay_nonce", envelope, payload)
        if not envelope.signature.startswith("sig:"):
            return self._reject("invalid_signature", envelope, payload)
        expected_payload_hash = keccak256_like(payload)
        if expected_payload_hash != envelope.payload_hash:
            return self._reject("artifact_tampering", envelope, payload)
        self.used_nonces.add(nonce_key)
        return ValidationResult(True, "accepted", self.commit(envelope, payload))

    def commit(self, envelope: UpdateEnvelope, payload: dict) -> str:
        return keccak256_like({"envelope": envelope.__dict__, "payload": payload})

    def _reject(self, reason: str, envelope: UpdateEnvelope, payload: dict) -> ValidationResult:
        return ValidationResult(False, reason, self.commit(envelope, payload))


def make_envelope(device_id: str, nonce: int, model_version: int, payload: dict) -> UpdateEnvelope:
    payload_hash = keccak256_like(payload)
    return UpdateEnvelope(
        device_id=device_id,
        did=f"did:iobt:{device_id}",
        vc_id=f"vc:{device_id}",
        signature=f"sig:{device_id}:{payload_hash[:12]}",
        nonce=nonce,
        model_version=model_version,
        update_hash=payload_hash,
        payload_hash=payload_hash,
    )

