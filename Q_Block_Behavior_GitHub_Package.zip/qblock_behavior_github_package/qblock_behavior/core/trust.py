"""Adaptive trust and poisoning-risk computation."""

from __future__ import annotations

import numpy as np


def coordinate_median(updates: list[np.ndarray]) -> np.ndarray:
    if not updates:
        raise ValueError("At least one update is required")
    return np.median(np.stack(updates, axis=0), axis=0)


def cosine_distance(a: np.ndarray, b: np.ndarray, eps: float = 1e-8) -> float:
    denom = np.linalg.norm(a) * np.linalg.norm(b) + eps
    return float(1.0 - np.dot(a, b) / denom)


def poisoning_risk(update: np.ndarray, reference: np.ndarray, omega1: float = 0.5, omega2: float = 0.5) -> float:
    magnitude = np.linalg.norm(update - reference) / (np.linalg.norm(reference) + 1e-8)
    direction = cosine_distance(update, reference) / 2.0
    return float(np.clip(omega1 * magnitude + omega2 * direction, 0.0, 1.0))


def consistency_score(update: np.ndarray, reference: np.ndarray) -> float:
    return float(np.clip(1.0 - poisoning_risk(update, reference), 0.0, 1.0))


def adaptive_trust(
    quantum_fidelity: float,
    contract_valid: bool,
    reliability: float,
    consistency: float,
    poisoning: float,
) -> float:
    contract_score = 1.0 if contract_valid else 0.0
    trust = (
        0.20 * quantum_fidelity
        + 0.25 * contract_score
        + 0.20 * reliability
        + 0.20 * consistency
        + 0.15 * (1.0 - poisoning)
    )
    return float(np.clip(trust, 0.0, 1.0))


def trust_weighted_aggregate(updates: list[np.ndarray], trusts: list[float], tau_trust: float = 0.70) -> np.ndarray:
    accepted = [(u, t) for u, t in zip(updates, trusts) if t >= tau_trust]
    if not accepted:
        return np.zeros_like(updates[0])
    weights = np.array([t for _, t in accepted], dtype=float)
    weights = weights / weights.sum()
    stacked = np.stack([u for u, _ in accepted], axis=0)
    return np.sum(stacked * weights[:, None], axis=0)

