"""Model poisoning attacks for federated update simulation."""

from __future__ import annotations

import numpy as np


def label_flip(y: np.ndarray) -> np.ndarray:
    return 1 - y.astype(int)


def sign_flip(update: np.ndarray, scale: float = -5.0) -> np.ndarray:
    return scale * update


def gaussian_noise(update: np.ndarray, benign_std: float, sigma_multiplier: float = 3.0, seed: int = 42) -> np.ndarray:
    rng = np.random.default_rng(seed)
    sigma = sigma_multiplier * max(float(benign_std), 1e-8)
    return update + rng.normal(0.0, sigma, size=update.shape)


def model_replacement(update: np.ndarray, participants: int, scale: float | None = None) -> np.ndarray:
    factor = float(scale if scale is not None else participants)
    return update * factor


def inject_attack(update: np.ndarray, attack: str, benign_std: float, participants: int, seed: int) -> np.ndarray:
    if attack == "sign_flip":
        return sign_flip(update)
    if attack == "gaussian":
        return gaussian_noise(update, benign_std=benign_std, seed=seed)
    if attack == "model_replacement":
        return model_replacement(update, participants=participants)
    if attack == "none":
        return update
    raise ValueError(f"Unsupported attack: {attack}")

