"""Evaluation metrics for Q-Block_Behavior."""

from __future__ import annotations

import numpy as np
from sklearn.metrics import accuracy_score, confusion_matrix, f1_score, roc_auc_score


def classification_report_dict(y_true: np.ndarray, y_pred: np.ndarray, y_score: np.ndarray | None = None) -> dict[str, float]:
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred, labels=[0, 1]).ravel()
    report = {
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "f1": float(f1_score(y_true, y_pred, zero_division=0)),
        "detection_rate": float(tp / max(tp + fn, 1)),
        "false_positive_rate": float(fp / max(fp + tn, 1)),
    }
    if y_score is not None:
        report["auc"] = float(roc_auc_score(y_true, y_score))
    return report


def attack_success_rate(malicious_total: int, malicious_accepted: int) -> float:
    return float(malicious_accepted / max(malicious_total, 1))

