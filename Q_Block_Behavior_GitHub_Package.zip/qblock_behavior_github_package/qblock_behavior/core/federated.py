"""Federated-learning update simulation."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from qblock_behavior.core.attacks import inject_attack
from qblock_behavior.core.blockchain import LedgerValidator, make_envelope
from qblock_behavior.core.trust import adaptive_trust, consistency_score, coordinate_median, poisoning_risk, trust_weighted_aggregate


@dataclass
class RoundResult:
    round_id: int
    accepted_updates: int
    rejected_updates: int
    quarantined_updates: int
    mean_trust: float
    global_update_norm: float
    commitments: list[str]


def simulate_local_update(x: np.ndarray, y: np.ndarray, model_dim: int, seed: int) -> np.ndarray:
    rng = np.random.default_rng(seed)
    signal = x.mean(axis=0)
    label_shift = float(y.mean() - 0.5)
    base = np.resize(signal, model_dim) * label_shift
    return base + rng.normal(0.0, 0.01, model_dim)


def run_federated_round(
    round_id: int,
    x: np.ndarray,
    y: np.ndarray,
    partitions: list[np.ndarray],
    malicious_clients: set[int],
    validator: LedgerValidator,
    tau_trust: float,
    seed: int,
) -> tuple[np.ndarray, RoundResult]:
    updates: list[np.ndarray] = []
    payloads: list[dict] = []
    model_dim = 16
    for client_id, idx in enumerate(partitions):
        update = simulate_local_update(x[idx], y[idx], model_dim=model_dim, seed=seed + client_id)
        if client_id in malicious_clients:
            attack = ["sign_flip", "gaussian", "model_replacement"][client_id % 3]
            update = inject_attack(update, attack, benign_std=0.05, participants=len(partitions), seed=seed + client_id)
        payload = {"client_id": client_id, "round": round_id, "update": update.round(8).tolist()}
        updates.append(update)
        payloads.append(payload)

    reference = coordinate_median(updates)
    trusts: list[float] = []
    commitments: list[str] = []
    rejected = 0
    quarantined = 0
    for client_id, (update, payload) in enumerate(zip(updates, payloads)):
        envelope = make_envelope(f"device-{client_id:03d}", nonce=round_id + 1000 * client_id, model_version=round_id, payload=payload)
        validation = validator.verify(envelope, payload)
        commitments.append(validation.commitment)
        p = poisoning_risk(update, reference)
        c = consistency_score(update, reference)
        reliability = 0.95 if client_id not in malicious_clients else 0.45
        q_fidelity = 0.96 if client_id not in malicious_clients else 0.70
        trust = adaptive_trust(q_fidelity, validation.accepted, reliability, c, p)
        trusts.append(trust)
        if not validation.accepted:
            rejected += 1
        elif trust < tau_trust:
            quarantined += 1

    aggregate = trust_weighted_aggregate(updates, trusts, tau_trust=tau_trust)
    accepted = sum(t >= tau_trust for t in trusts)
    result = RoundResult(
        round_id=round_id,
        accepted_updates=accepted,
        rejected_updates=rejected,
        quarantined_updates=quarantined,
        mean_trust=float(np.mean(trusts)),
        global_update_norm=float(np.linalg.norm(aggregate)),
        commitments=commitments,
    )
    return aggregate, result

