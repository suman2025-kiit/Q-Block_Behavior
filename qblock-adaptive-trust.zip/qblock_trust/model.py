"""Adaptive trust evaluation for Q-Block_Behavior.

The blockchain/smart-contract layer supplies ``validation_flag``. This module
does not duplicate DID, credential, signature, or block-hash verification.
"""

from dataclasses import dataclass
from typing import Dict, Iterable

import numpy as np
from numpy.typing import NDArray

Vector = NDArray[np.float64]


@dataclass(frozen=True)
class DeviceSubmission:
    """Evidence and local model submitted by one IoB device."""

    device_id: str
    local_model: Vector
    sample_count: int
    fidelity: float
    validation_flag: int


@dataclass(frozen=True)
class DeviceResult:
    """Trust factors and admission decision for one device."""

    device_id: str
    reliability: float
    consistency: float
    poisoning_risk: float
    trust: float
    normalized_trust: float
    accepted: bool
    weight: float = 0.0


@dataclass(frozen=True)
class RoundResult:
    """Global model and per-device decisions returned for a round."""

    global_model: Vector
    devices: Dict[str, DeviceResult]


class AdaptiveTrustModel:
    """Implements the trust equations and trust-weighted aggregation."""

    def __init__(
        self,
        *,
        alpha: float = 0.25,
        beta: float = 0.25,
        gamma: float = 0.20,
        delta: float = 0.20,
        poison_penalty: float = 0.10,
        eta: float = 0.80,
        trust_threshold: float = 0.70,
        epsilon: float = 1e-12,
    ) -> None:
        coefficients = [alpha, beta, gamma, delta, poison_penalty]
        if any(value < 0 for value in coefficients):
            raise ValueError("Trust coefficients must be non-negative")
        if not 0 <= eta <= 1 or not 0 <= trust_threshold <= 1:
            raise ValueError("eta and trust_threshold must lie in [0, 1]")
        self.alpha, self.beta = alpha, beta
        self.gamma, self.delta = gamma, delta
        self.poison_penalty, self.eta = poison_penalty, eta
        self.trust_threshold, self.epsilon = trust_threshold, epsilon
        self.reliability: Dict[str, float] = {}

    def historical_reliability(self, device_id: str, validation_flag: int) -> float:
        """R_i(t) = eta*R_i(t-1) + (1-eta)*V_i(t)."""
        previous = self.reliability.get(device_id, 0.5)
        current = self.eta * previous + (1.0 - self.eta) * validation_flag
        self.reliability[device_id] = float(np.clip(current, 0.0, 1.0))
        return self.reliability[device_id]

    def consistency(self, update: Vector, reference_update: Vector) -> float:
        """Map cosine similarity between a local and reference update to [0,1]."""
        denominator = np.linalg.norm(update) * np.linalg.norm(reference_update)
        cosine = float(np.dot(update, reference_update) / (denominator + self.epsilon))
        return float(np.clip(0.5 * (1.0 + cosine), 0.0, 1.0))

    def poisoning_risk(self, update: Vector, reference_update: Vector) -> float:
        """Bound relative update deviation to [0,1]."""
        deviation = np.linalg.norm(update - reference_update)
        scale = np.linalg.norm(reference_update) + self.epsilon
        return float(np.clip(deviation / (deviation + scale), 0.0, 1.0))

    def trust_score(
        self,
        fidelity: float,
        validation_flag: int,
        reliability: float,
        consistency: float,
        poisoning_risk: float,
    ) -> float:
        score = (
            self.alpha * fidelity
            + self.beta * validation_flag
            + self.gamma * reliability
            + self.delta * consistency
            - self.poison_penalty * poisoning_risk
        )
        return float(np.clip(score, 0.0, 1.0))

    def aggregate_round(
        self,
        global_model: Vector,
        submissions: Iterable[DeviceSubmission],
        reference_update: Vector | None = None,
    ) -> RoundResult:
        """Evaluate devices and return the trust-weighted global model."""
        global_model = np.asarray(global_model, dtype=np.float64)
        entries = list(submissions)
        if not entries:
            return RoundResult(global_model.copy(), {})

        for item in entries:
            if item.sample_count <= 0:
                raise ValueError("sample_count must be positive")
            if item.validation_flag not in (0, 1):
                raise ValueError("validation_flag must be 0 or 1")
            if not 0 <= item.fidelity <= 1:
                raise ValueError("fidelity must lie in [0, 1]")
            if np.asarray(item.local_model).shape != global_model.shape:
                raise ValueError("All local models must match global_model shape")

        updates = [np.asarray(x.local_model, dtype=np.float64) - global_model for x in entries]
        if reference_update is None:
            reference_update = np.median(np.stack(updates), axis=0)
        reference_update = np.asarray(reference_update, dtype=np.float64)

        provisional: Dict[str, DeviceResult] = {}
        for item, update in zip(entries, updates):
            reliability = self.historical_reliability(item.device_id, item.validation_flag)
            consistency = self.consistency(update, reference_update)
            risk = self.poisoning_risk(update, reference_update)
            trust = self.trust_score(
                item.fidelity, item.validation_flag, reliability, consistency, risk
            )
            accepted = item.validation_flag == 1 and trust >= self.trust_threshold
            provisional[item.device_id] = DeviceResult(
                item.device_id, reliability, consistency, risk, trust, 0.0, accepted
            )

        positive_total = sum(max(result.trust, 0.0) for result in provisional.values())
        trusted = [x for x in entries if provisional[x.device_id].accepted]
        weight_total = sum(provisional[x.device_id].trust * x.sample_count for x in trusted)
        if not trusted or weight_total <= self.epsilon:
            return RoundResult(global_model.copy(), provisional)

        aggregated = np.zeros_like(global_model)
        final: Dict[str, DeviceResult] = {}
        for item in entries:
            result = provisional[item.device_id]
            normalized = result.trust / (positive_total + self.epsilon)
            weight = (
                result.trust * item.sample_count / weight_total if result.accepted else 0.0
            )
            if result.accepted:
                aggregated += weight * np.asarray(item.local_model, dtype=np.float64)
            final[item.device_id] = DeviceResult(
                result.device_id,
                result.reliability,
                result.consistency,
                result.poisoning_risk,
                result.trust,
                normalized,
                result.accepted,
                weight,
            )
        return RoundResult(aggregated, final)

