"""Reproducible Adaptive Trust Model demonstration."""

import numpy as np

from qblock_trust import AdaptiveTrustModel, DeviceSubmission


def main() -> None:
    model = AdaptiveTrustModel(trust_threshold=0.70)
    global_model = np.array([0.20, -0.10, 0.30, 0.05])
    submissions = [
        DeviceSubmission("did:qblock:01", np.array([0.24, -0.08, 0.34, 0.07]), 120, 0.97, 1),
        DeviceSubmission("did:qblock:02", np.array([0.23, -0.07, 0.33, 0.08]), 100, 0.95, 1),
        DeviceSubmission("did:qblock:03", np.array([2.40, -2.20, 3.10, -1.80]), 150, 0.91, 1),
        DeviceSubmission("did:qblock:04", np.array([0.22, -0.09, 0.31, 0.06]), 90, 0.96, 0),
    ]
    result = model.aggregate_round(global_model, submissions)

    print("device,validated,reliability,consistency,risk,trust,accepted,weight")
    for item in submissions:
        r = result.devices[item.device_id]
        print(
            f"{item.device_id},{item.validation_flag},{r.reliability:.3f},"
            f"{r.consistency:.3f},{r.poisoning_risk:.3f},{r.trust:.3f},"
            f"{r.accepted},{r.weight:.3f}"
        )
    print("global_model:", np.round(result.global_model, 6))


if __name__ == "__main__":
    main()

