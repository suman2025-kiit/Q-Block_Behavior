// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/// @notice Minimal research gateway supplying V_i(t) to the trust model.
/// Production deployments should connect audited DID/VC verification.
contract QBlockValidation {
    struct Record {
        bytes32 artifactHash;
        bytes32 previousHash;
        bytes32 didHash;
        uint256 nonce;
        bool validationFlag;
    }

    mapping(uint256 => bool) public usedNonce;
    mapping(bytes32 => Record) public records;

    event RecordValidated(
        bytes32 indexed deviceId,
        bytes32 indexed artifactHash,
        bool validationFlag
    );

    function validateRecord(
        bytes32 deviceId,
        bytes32 artifactHash,
        bytes32 previousHash,
        bytes32 didHash,
        uint256 nonce,
        bool credentialValid,
        bool signatureValid
    ) external returns (bool) {
        require(!usedNonce[nonce], "NONCE_USED");
        require(credentialValid, "VC_INVALID");
        require(signatureValid, "BAD_SIGNATURE");
        require(deviceId != bytes32(0) && didHash != bytes32(0), "DID_INVALID");
        require(artifactHash != bytes32(0), "HASH_INVALID");

        usedNonce[nonce] = true;
        records[deviceId] = Record(
            artifactHash, previousHash, didHash, nonce, true
        );
        emit RecordValidated(deviceId, artifactHash, true);
        return true;
    }
}
