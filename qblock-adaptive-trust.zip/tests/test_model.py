import unittest

import numpy as np

from qblock_trust import AdaptiveTrustModel, DeviceSubmission


class AdaptiveTrustTests(unittest.TestCase):
    def test_invalid_contract_record_is_rejected(self) -> None:
        engine = AdaptiveTrustModel(trust_threshold=0.60)
        result = engine.aggregate_round(
            np.zeros(2),
            [DeviceSubmission("bad-vc", np.array([0.1, 0.1]), 10, 0.99, 0)],
            reference_update=np.array([0.1, 0.1]),
        )
        self.assertFalse(result.devices["bad-vc"].accepted)
        np.testing.assert_allclose(result.global_model, np.zeros(2))

    def test_consistent_valid_updates_are_aggregated(self) -> None:
        engine = AdaptiveTrustModel(trust_threshold=0.60)
        inputs = [
            DeviceSubmission("d1", np.array([1.0, 1.0]), 10, 0.98, 1),
            DeviceSubmission("d2", np.array([1.2, 1.2]), 20, 0.96, 1),
        ]
        result = engine.aggregate_round(np.zeros(2), inputs)
        self.assertTrue(all(x.accepted for x in result.devices.values()))
        self.assertAlmostEqual(sum(x.weight for x in result.devices.values()), 1.0)
        self.assertTrue(np.all(result.global_model > 1.0))

    def test_opposite_poisoned_update_has_lower_trust(self) -> None:
        engine = AdaptiveTrustModel(trust_threshold=0.70)
        inputs = [
            DeviceSubmission("good", np.array([0.1, 0.1]), 10, 0.99, 1),
            DeviceSubmission("poison", np.array([-4.0, -4.0]), 10, 0.99, 1),
        ]
        result = engine.aggregate_round(
            np.zeros(2), inputs, reference_update=np.array([0.1, 0.1])
        )
        self.assertGreater(
            result.devices["good"].trust, result.devices["poison"].trust
        )
        self.assertTrue(result.devices["good"].accepted)
        self.assertFalse(result.devices["poison"].accepted)


if __name__ == "__main__":
    unittest.main()
