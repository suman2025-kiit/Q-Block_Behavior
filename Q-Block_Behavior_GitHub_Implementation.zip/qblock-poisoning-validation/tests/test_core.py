import json
from pathlib import Path

import numpy as np

from qblock_poisoning.core import DetectorConfig, evaluate_updates
from qblock_poisoning.simulation import run_experiment


def test_coordinate_median_rejects_extreme_update():
    updates = np.asarray(
        [[1.00, 1.00], [1.02, 0.98], [0.98, 1.02], [-5.0, -5.0]], dtype=float
    )
    result = evaluate_updates(
        updates,
        fidelity=[0.97] * 4,
        validation=[1] * 4,
        previous_reliability=[0.95] * 4,
        config=DetectorConfig(),
    )
    assert np.allclose(result.reference_update, [0.99, 0.99])
    assert result.decisions[0].accepted
    assert not result.decisions[3].accepted
    assert result.decisions[3].poisoning_risk == 1.0


def test_invalid_credential_is_quarantined():
    result = evaluate_updates(
        np.asarray([[1.0, 1.0], [1.01, 0.99]]),
        fidelity=[0.98, 0.98],
        validation=[1, 0],
        previous_reliability=[0.95, 0.95],
    )
    assert result.decisions[0].accepted
    assert not result.decisions[1].accepted
    assert result.decisions[1].trust == 0.0


def test_no_authenticated_update_produces_no_aggregate():
    result = evaluate_updates(
        np.ones((3, 4)), [0.9] * 3, [0] * 3, [0.9] * 3
    )
    assert result.aggregate_update is None
    assert all(not decision.accepted for decision in result.decisions)


def test_end_to_end_outputs(tmp_path):
    raw = json.loads(Path("config/manuscript.json").read_text(encoding="utf-8"))
    raw["experiment"]["rounds"] = 2
    raw["experiment"]["seeds"] = [11]
    result = run_experiment(raw, tmp_path)
    assert result["decisions"] == 2 * 4 * 20
    assert len(result["final_hash"]) == 64
    assert (tmp_path / "device_decisions.csv").exists()
    assert (tmp_path / "round_metrics.csv").exists()
    assert (tmp_path / "attack_summary.csv").exists()
    assert (tmp_path / "l2_commitments.jsonl").exists()
