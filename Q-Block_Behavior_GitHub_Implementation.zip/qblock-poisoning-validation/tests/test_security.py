import time
import numpy as np
from qblock_poisoning.audit import make_record
from qblock_poisoning.identity import Credential, SignedSubmission, ValidationRegistry
from qblock_poisoning.preprocessing import dirichlet_partition, qpca_inspired_rank
from qblock_poisoning.quantum import fidelity, ghz_reference, zz_inspired_state

def test_ghz_is_separate_reference():
    encoded = zz_inspired_state(np.array([0.1, 0.2, 0.3, 0.4]))
    assert encoded.shape == ghz_reference().shape == (16,)
    assert 0 <= fidelity(encoded) <= 1
    assert np.isclose(fidelity(ghz_reference()), 1)

def test_replay_is_rejected():
    now = int(time.time()); issuer = "did:qblock:issuer"; did = "did:qblock:device:1"
    registry = ValidationRegistry({issuer: b"test-secret"})
    credential = Credential("vc-1", did, issuer, now + 60)
    artifact = {"round": 1}; record = make_record(artifact, "0" * 64, did, "nonce-1", now)
    submission = SignedSubmission(artifact, record, credential, registry.sign(artifact, credential))
    assert registry.validate(submission, now=now)[0]
    assert registry.validate(submission, now=now) == (False, "replayed_nonce")

def test_partition_and_ranking():
    labels = np.array([0] * 100 + [1] * 100)
    parts = dirichlet_partition(labels, devices=4, alpha=0.5, seed=42, minimum=10)
    assert sum(map(len, parts)) == 200
    assert len(qpca_inspired_rank(np.random.default_rng(1).normal(size=(30, 16)))) == 4
