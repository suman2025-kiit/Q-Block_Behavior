// SPDX-License-Identifier: MIT
pragma solidity 0.8.24;

contract QBlockValidation {
    address public owner;
    mapping(address => bool) public approvedIssuers;
    mapping(bytes32 => bool) public revokedCredentials;
    mapping(bytes32 => bool) public usedNonces;
    mapping(bytes32 => bool) public commitments;

    event CredentialStatus(bytes32 indexed credentialId, bool revoked);
    event ArtifactValidated(bytes32 indexed artifactHash, bytes32 indexed didHash);
    event GlobalModelCommitted(bytes32 indexed modelHash, uint256 round);

    constructor() { owner = msg.sender; approvedIssuers[msg.sender] = true; }
    modifier onlyOwner() { require(msg.sender == owner, "owner only"); _; }

    function setIssuer(address issuer, bool approved) external onlyOwner {
        approvedIssuers[issuer] = approved;
    }
    function setRevocation(bytes32 credentialId, bool revoked) external onlyOwner {
        revokedCredentials[credentialId] = revoked;
        emit CredentialStatus(credentialId, revoked);
    }
    function validateArtifact(bytes32 artifactHash, bytes32 didHash,
        bytes32 credentialId, bytes32 nonce, uint256 expiresAt,
        address issuer, bytes calldata signature) external returns (bool) {
        require(approvedIssuers[issuer], "unknown issuer");
        require(!revokedCredentials[credentialId], "revoked credential");
        require(block.timestamp <= expiresAt, "expired credential");
        require(!usedNonces[nonce], "replayed nonce");
        bytes32 message = keccak256(abi.encodePacked(artifactHash, didHash, credentialId, nonce, expiresAt));
        require(_recover(_ethSigned(message), signature) == issuer, "signature mismatch");
        usedNonces[nonce] = true; commitments[artifactHash] = true;
        emit ArtifactValidated(artifactHash, didHash); return true;
    }
    function commitGlobalModel(bytes32 modelHash, uint256 round) external onlyOwner {
        require(modelHash != bytes32(0), "empty commitment");
        commitments[modelHash] = true; emit GlobalModelCommitted(modelHash, round);
    }
    function _ethSigned(bytes32 hash) private pure returns (bytes32) {
        return keccak256(abi.encodePacked("\x19Ethereum Signed Message:\n32", hash));
    }
    function _recover(bytes32 hash, bytes memory signature) private pure returns (address) {
        require(signature.length == 65, "invalid signature length");
        bytes32 r; bytes32 s; uint8 v;
        assembly { r := mload(add(signature, 32)) s := mload(add(signature, 64)) v := byte(0, mload(add(signature, 96))) }
        if (v < 27) v += 27;
        require(v == 27 || v == 28, "invalid signature v");
        return ecrecover(hash, v, r, s);
    }
}
