"""Algorithm 5 coordinator for reproducible poisoning-validation runs."""
from __future__ import annotations
import csv, json, math, time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any
import numpy as np
from .attacks import poison_update
from .audit import batch_commitment, make_record
from .core import DetectorConfig, evaluate_updates
from .identity import Credential, SignedSubmission, ValidationRegistry

@dataclass
class Counts:
    tp: int = 0; tn: int = 0; fp: int = 0; fn: int = 0
    def update(self, malicious: bool, quarantined: bool) -> None:
        if malicious and quarantined: self.tp += 1
        elif malicious: self.fn += 1
        elif quarantined: self.fp += 1
        else: self.tn += 1
    def metrics(self) -> tuple[float, float, float]:
        dr = 100 * self.tp / max(self.tp + self.fn, 1)
        fpr = 100 * self.fp / max(self.fp + self.tn, 1)
        bypass = 100 * self.fn / max(self.tp + self.fn, 1)
        return dr, fpr, bypass

def load_config(path: Path) -> dict[str, Any]:
    raw = json.loads(path.read_text(encoding="utf-8"))
    if "config" in raw: raw = json.loads((path.parent / raw["config"]).read_text(encoding="utf-8"))
    return raw

def detector_config(raw: dict[str, Any]) -> DetectorConfig:
    d, p, w = raw["detector"], raw["detector"]["poisoning_weights"], raw["detector"]["trust_weights"]
    return DetectorConfig(d["trust_threshold"], d["reliability_eta"], d["epsilon"], p["magnitude"], p["direction"], w["fidelity"], w["validation"], w["reliability"], w["consistency"], w["poisoning_penalty"])

def malicious_assignment(devices: int, ratio: float, seed: int, round_id: int) -> np.ndarray:
    rng = np.random.default_rng(seed * 100_003 + round_id)
    mask = np.zeros(devices, dtype=bool)
    mask[rng.choice(devices, math.ceil(ratio * devices), replace=False)] = True
    return mask

def generate_round(raw: dict[str, Any], attack: str, seed: int, round_id: int) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    exp, model, params = raw["experiment"], raw["model"], raw["attacks"]
    devices, dimension = exp["num_devices"], model["update_dimension"]
    rng = np.random.default_rng(seed * 1_000_003 + round_id)
    malicious = malicious_assignment(devices, exp["malicious_ratio"], seed, round_id)
    direction = rng.normal(size=dimension); direction /= np.linalg.norm(direction)
    updates = direction + rng.normal(0, 0.055, (devices, dimension))
    attack_rng = np.random.default_rng(seed * 10_000_019 + round_id + 97 * params["names"].index(attack))
    for device_id in np.flatnonzero(malicious):
        updates[device_id] = poison_update(updates[device_id], attack, attack_rng, sign_scale=params["sign_scale"], gaussian_std_multiplier=params["gaussian_std_multiplier"], model_replacement_scale=params["model_replacement_scale"])
    fidelity = np.clip(rng.normal(0.96, 0.012, devices), 0, 1)
    counts = rng.integers(exp["minimum_device_records"], 501, devices)
    return updates, fidelity, np.ones(devices, dtype=int), counts, malicious

def _mean_sd_ci(values: list[float]) -> dict[str, float]:
    data = np.asarray(values, dtype=float); mean = float(np.mean(data))
    sd = float(np.std(data, ddof=1)) if len(data) > 1 else 0.0
    # t(0.975,4)=2.776 for the five manuscript seeds.
    critical = 2.776 if len(data) == 5 else 1.96
    half = critical * sd / math.sqrt(max(len(data), 1))
    return {"mean": mean, "sd": sd, "ci_low": mean - half, "ci_high": mean + half}

def run_experiment(raw: dict[str, Any], output_dir: Path) -> dict[str, Any]:
    output_dir.mkdir(parents=True, exist_ok=True)
    exp, chain, cfg = raw["experiment"], raw["blockchain"], detector_config(raw)
    device_rows, round_rows, batch_rows, per_seed = [], [], [], []
    previous_global_hash = "0" * 64
    now = int(time.time()); issuer = "did:qblock:issuer"
    registry = ValidationRegistry({issuer: b"demo-only-secret-change-before-deployment"})
    for attack in raw["attacks"]["names"]:
        for seed in exp["seeds"]:
            reliability = np.full(exp["num_devices"], 0.95); seed_counts = Counts()
            for round_id in range(1, exp["rounds"] + 1):
                updates, fidelity, validation, samples, malicious = generate_round(raw, attack, seed, round_id)
                records = []
                for device_id in range(exp["num_devices"]):
                    did = f"did:qblock:device:{device_id}"
                    artifact = {"device": device_id, "round": round_id, "seed": seed, "attack": attack, "update_digest_input": np.round(updates[device_id], 8).tolist()}
                    record = make_record(artifact, previous_global_hash, did, f"{attack}:{seed}:{round_id}:{device_id}", now)
                    credential = Credential(f"vc-{device_id}", did, issuer, now + 3600)
                    signature = registry.sign(artifact, credential)
                    valid, reason = registry.validate(SignedSubmission(artifact, record, credential, signature), now=now, maximum_clock_skew_seconds=chain["maximum_clock_skew_seconds"])
                    validation[device_id] = int(valid); records.append(record)
                result = evaluate_updates(updates, fidelity, validation, reliability, samples, cfg)
                reliability = np.asarray([decision.reliability for decision in result.decisions])
                counts = Counts()
                for decision in result.decisions:
                    bad = bool(malicious[decision.device_id]); quarantine = not decision.accepted
                    counts.update(bad, quarantine); seed_counts.update(bad, quarantine)
                    device_rows.append({"attack": attack, "seed": seed, "round": round_id, "device_id": decision.device_id, "malicious": int(bad), "authenticated": int(decision.authenticated), "fidelity": f"{decision.fidelity:.6f}", "reliability": f"{decision.reliability:.6f}", "consistency": f"{decision.consistency:.6f}", "magnitude_deviation": f"{decision.magnitude_deviation:.6f}", "poisoning_risk": f"{decision.poisoning_risk:.6f}", "trust": f"{decision.trust:.6f}", "decision": "ACCEPT" if decision.accepted else "QUARANTINE"})
                dr, fpr, bypass = counts.metrics()
                commitment = batch_commitment(records); previous_global_hash = commitment["root"]
                batch_rows.append({"attack": attack, "seed": seed, "round": round_id, **commitment})
                round_rows.append({"attack": attack, "seed": seed, "round": round_id, "tp": counts.tp, "tn": counts.tn, "fp": counts.fp, "fn": counts.fn, "dr_percent": f"{dr:.3f}", "fpr_percent": f"{fpr:.3f}", "update_bypass_percent": f"{bypass:.3f}", "accepted": sum(d.accepted for d in result.decisions), "l2_commitment": previous_global_hash})
            dr, fpr, bypass = seed_counts.metrics()
            per_seed.append({"attack": attack, "seed": seed, "dr": dr, "fpr": fpr, "bypass": bypass, **asdict(seed_counts)})
    summary = []
    for attack in raw["attacks"]["names"]:
        rows = [row for row in per_seed if row["attack"] == attack]
        summary.append({"attack": attack, "detection_rate_percent": _mean_sd_ci([r["dr"] for r in rows]), "false_positive_rate_percent": _mean_sd_ci([r["fpr"] for r in rows]), "update_bypass_percent": _mean_sd_ci([r["bypass"] for r in rows])})
    _write_csv(output_dir / "device_decisions.csv", device_rows); _write_csv(output_dir / "round_metrics.csv", round_rows); _write_csv(output_dir / "seed_metrics.csv", per_seed)
    flat_summary = [{"attack": r["attack"], **{f"{metric}_{field}": value for metric in ("detection_rate_percent", "false_positive_rate_percent", "update_bypass_percent") for field, value in r[metric].items()}} for r in summary]
    _write_csv(output_dir / "attack_summary.csv", flat_summary)
    with (output_dir / "l2_commitments.jsonl").open("w", encoding="utf-8") as handle:
        for row in batch_rows: handle.write(json.dumps(row, sort_keys=True) + "\n")
    return {"summary": summary, "decisions": len(device_rows), "rounds": len(round_rows), "final_hash": previous_global_hash, "hash_algorithm": batch_rows[-1]["hash_algorithm"]}

def _write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows: raise ValueError(f"cannot write empty CSV: {path}")
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0])); writer.writeheader(); writer.writerows(rows)
