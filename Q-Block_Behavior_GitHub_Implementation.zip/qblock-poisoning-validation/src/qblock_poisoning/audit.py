"""Canonical off-chain records and Layer-2 batch commitments."""
from __future__ import annotations
import hashlib, json
from dataclasses import asdict, dataclass
from typing import Any, Iterable
try:
    from Crypto.Hash import keccak
except ImportError:  # pragma: no cover
    keccak = None

def canonical_bytes(value: Any) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()

def digest(value: Any) -> tuple[str, str]:
    payload = value if isinstance(value, bytes) else canonical_bytes(value)
    if keccak is not None:
        state = keccak.new(digest_bits=256); state.update(payload)
        return state.hexdigest(), "keccak-256"
    return hashlib.sha3_256(payload).hexdigest(), "sha3-256-fallback"

@dataclass(frozen=True)
class AuditRecord:
    artifact_hash: str
    previous_hash: str
    did: str
    nonce: str
    timestamp: int
    hash_algorithm: str

def make_record(artifact: dict[str, Any], previous_hash: str, did: str, nonce: str, timestamp: int) -> AuditRecord:
    artifact_hash, algorithm = digest({"artifact": artifact, "previous_hash": previous_hash})
    return AuditRecord(artifact_hash, previous_hash, did, nonce, timestamp, algorithm)

def chained_commitment(payload: dict[str, Any], previous_hash: str) -> str:
    value, _ = digest({"payload": payload, "previous_hash": previous_hash})
    return value

def batch_commitment(records: Iterable[AuditRecord]) -> dict[str, Any]:
    leaves = [asdict(record) for record in records]
    root, algorithm = digest(leaves)
    return {"root": root, "hash_algorithm": algorithm, "record_count": len(leaves)}
