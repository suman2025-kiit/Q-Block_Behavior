"""Algorithm 3: deterministic DID/VC and artifact validation."""
from __future__ import annotations
import hmac, time
from dataclasses import dataclass, field
from typing import Mapping
from .audit import AuditRecord, canonical_bytes, digest

@dataclass(frozen=True)
class Credential:
    credential_id: str
    subject_did: str
    issuer_did: str
    expires_at: int

@dataclass(frozen=True)
class SignedSubmission:
    artifact: dict
    record: AuditRecord
    credential: Credential
    signature: str

@dataclass
class ValidationRegistry:
    issuer_secrets: Mapping[str, bytes]
    revoked_credentials: set[str] = field(default_factory=set)
    used_nonces: set[str] = field(default_factory=set)
    commitments: list[str] = field(default_factory=list)

    def sign(self, artifact: dict, credential: Credential) -> str:
        key = self.issuer_secrets[credential.issuer_did]
        message = canonical_bytes({"artifact": artifact, "subject_did": credential.subject_did})
        return hmac.new(key, message, "sha256").hexdigest()

    def validate(self, submission: SignedSubmission, *, now: int | None = None, maximum_clock_skew_seconds: int = 300) -> tuple[bool, str]:
        current = int(time.time()) if now is None else int(now)
        credential, record = submission.credential, submission.record
        if credential.credential_id in self.revoked_credentials: return False, "revoked_credential"
        if credential.expires_at < current: return False, "expired_credential"
        if credential.subject_did != record.did: return False, "did_mismatch"
        if abs(current - record.timestamp) > maximum_clock_skew_seconds: return False, "stale_timestamp"
        if record.nonce in self.used_nonces: return False, "replayed_nonce"
        if credential.issuer_did not in self.issuer_secrets: return False, "unknown_issuer"
        expected = self.sign(submission.artifact, credential)
        if not hmac.compare_digest(expected, submission.signature): return False, "signature_mismatch"
        expected_hash, algorithm = digest({"artifact": submission.artifact, "previous_hash": record.previous_hash})
        if expected_hash != record.artifact_hash or algorithm != record.hash_algorithm: return False, "artifact_hash_mismatch"
        self.used_nonces.add(record.nonce); self.commitments.append(record.artifact_hash)
        return True, "accepted"
