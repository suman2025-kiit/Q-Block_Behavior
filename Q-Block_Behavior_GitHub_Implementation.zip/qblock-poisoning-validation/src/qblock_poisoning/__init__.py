"""Q-Block_Behavior poisoning-detection reference implementation."""

from .core import DetectorConfig, RoundResult, evaluate_updates

__all__ = ["DetectorConfig", "RoundResult", "evaluate_updates"]
__version__ = "2.0.0"
