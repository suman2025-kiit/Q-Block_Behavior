"""Command-line interface for simulation and TON_IoT preparation."""
from __future__ import annotations
import argparse, json
from pathlib import Path
from .preprocessing import prepare_stratified_subset
from .simulation import load_config, run_experiment

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="qblock-poisoning")
    sub = parser.add_subparsers(dest="command", required=True)
    simulate = sub.add_parser("simulate"); simulate.add_argument("--config", type=Path, required=True); simulate.add_argument("--output-dir", type=Path, default=Path("outputs"))
    prepare = sub.add_parser("prepare-data"); prepare.add_argument("--csv", type=Path, required=True); prepare.add_argument("--output-dir", type=Path, required=True); prepare.add_argument("--seed", type=int, default=42); prepare.add_argument("--sample-size", type=int, default=20_000)
    return parser

def _report(raw: dict, result: dict) -> str:
    lines = ["Q-BLOCK_BEHAVIOR | POISONING-DETECTION RESULTS", "=" * 78, "Computed synthetic workflow test; not manuscript Table 5 results", f"devices={raw['experiment']['num_devices']} rounds={raw['experiment']['rounds']} seeds={raw['experiment']['seeds']} tau_T={raw['detector']['trust_threshold']:.2f}", "-" * 78, f"{'ATTACK':<20} {'DR mean':>10} {'FPR mean':>10} {'BYPASS mean':>12}"]
    for row in result["summary"]:
        lines.append(f"{row['attack']:<20} {row['detection_rate_percent']['mean']:>10.3f} {row['false_positive_rate_percent']['mean']:>10.3f} {row['update_bypass_percent']['mean']:>12.3f}")
    lines.extend(["-" * 78, f"evaluated decisions : {result['decisions']}", f"evaluated rounds    : {result['rounds']}", f"hash algorithm      : {result['hash_algorithm']}", f"final L2 commitment : {result['final_hash']}", "STATUS              : VALIDATION COMPLETED"])
    return "\n".join(lines) + "\n"

def main() -> None:
    args = build_parser().parse_args()
    if args.command == "prepare-data":
        print(json.dumps(prepare_stratified_subset(args.csv, args.output_dir, sample_size=args.sample_size, seed=args.seed), indent=2)); return
    raw = load_config(args.config); result = run_experiment(raw, args.output_dir)
    report = _report(raw, result); (args.output_dir / "sample_run.txt").write_text(report, encoding="utf-8"); print(report, end="")

if __name__ == "__main__": main()
