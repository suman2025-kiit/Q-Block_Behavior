"""Paper-aligned poisoning attacks."""
from __future__ import annotations
import numpy as np

def flip_binary_labels(labels: np.ndarray) -> np.ndarray:
    labels = np.asarray(labels, dtype=int)
    if np.any((labels != 0) & (labels != 1)):
        raise ValueError("label flipping requires binary labels")
    return 1 - labels

def poison_update(update: np.ndarray, attack: str, rng: np.random.Generator, *, sign_scale: float = -5.0, gaussian_std_multiplier: float = 3.0, model_replacement_scale: float = 20.0) -> np.ndarray:
    """Transform a local update; label flipping is a demo proxy here."""
    clean = np.asarray(update, dtype=float)
    if attack == "label_flipping":
        return -0.85 * clean + rng.normal(0.0, 0.12, clean.shape)
    if attack == "sign_flipping":
        return sign_scale * clean
    if attack == "gaussian_noise":
        sigma = max(float(np.std(clean)), 1e-3) * gaussian_std_multiplier
        return clean + rng.normal(0.0, sigma, clean.shape)
    if attack == "model_replacement":
        return model_replacement_scale * clean
    raise ValueError(f"unsupported attack: {attack}")
