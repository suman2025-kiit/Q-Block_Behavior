"""Algorithm 2: four-component encoding and GHZ-reference validation."""
from __future__ import annotations
import numpy as np

def ghz_reference(qubits: int = 4) -> np.ndarray:
    if qubits != 4: raise ValueError("the manuscript configuration uses four qubits")
    state = np.zeros(2**qubits, dtype=complex); state[0] = state[-1] = 1 / np.sqrt(2)
    return state

def zz_inspired_state(features: np.ndarray, repetitions: int = 2) -> np.ndarray:
    values = np.asarray(features, dtype=float)
    if values.shape != (4,): raise ValueError("exactly four ranked components are required")
    state = np.ones(16, dtype=complex) / 4
    bits = ((np.arange(16)[:, None] >> np.arange(4)) & 1); z = 1 - 2 * bits
    phase = z @ values
    for _ in range(repetitions):
        phase += np.sum((z[:, :-1] * z[:, 1:]) * (values[:-1] * values[1:]), axis=1)
    state *= np.exp(1j * phase)
    return state / np.linalg.norm(state)

def fidelity(encoded_state: np.ndarray, reference: np.ndarray | None = None) -> float:
    ref = ghz_reference() if reference is None else np.asarray(reference)
    return float(np.clip(abs(np.vdot(np.asarray(encoded_state), ref)) ** 2, 0, 1))

def shot_estimate(probability: float, shots: int, rng: np.random.Generator) -> float:
    if shots <= 0: raise ValueError("shots must be positive")
    return float(rng.binomial(shots, np.clip(probability, 0, 1)) / shots)

def qml_probability(features: np.ndarray, parameters: np.ndarray) -> float:
    score = float(np.dot(np.asarray(features), np.asarray(parameters)))
    return float(1 / (1 + np.exp(-np.clip(score, -30, 30))))
