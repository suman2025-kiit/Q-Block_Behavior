"""Algorithm 1 data preparation without train/test leakage."""
from __future__ import annotations
import csv, json
from pathlib import Path
import numpy as np

DROP_COLUMNS = {"ts", "timestamp", "src_ip", "dst_ip", "src_port", "dst_port", "type"}

def prepare_stratified_subset(csv_path: Path, output_dir: Path, *, sample_size: int = 20_000, seed: int = 42) -> dict:
    """Select a reproducible binary-label subset and publish source row indices."""
    with csv_path.open(newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        if not reader.fieldnames or "label" not in reader.fieldnames:
            raise ValueError("TON_IoT input must contain the binary 'label' column")
        rows = list(reader)
    groups: dict[str, list[int]] = {"0": [], "1": []}
    for index, row in enumerate(rows):
        label = str(row["label"]).strip()
        if label not in groups: raise ValueError(f"non-binary label at row {index}: {label}")
        groups[label].append(index)
    if sample_size > len(rows): raise ValueError("sample_size exceeds available rows")
    rng = np.random.default_rng(seed)
    benign_count = round(sample_size * len(groups["0"]) / len(rows))
    counts = {"0": benign_count, "1": sample_size - benign_count}
    selected = []
    for label in ("0", "1"):
        if counts[label] > len(groups[label]): raise ValueError("class lacks requested samples")
        selected.extend(rng.choice(groups[label], counts[label], replace=False).tolist())
    selected.sort(); output_dir.mkdir(parents=True, exist_ok=True)
    retained = [name for name in reader.fieldnames if name.lower() not in DROP_COLUMNS]
    with (output_dir / "ton_iot_subset.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, retained); writer.writeheader()
        writer.writerows({key: rows[index][key] for key in retained} for index in selected)
    (output_dir / "selected_indices.json").write_text(json.dumps({"seed": seed, "indices": selected}, indent=2), encoding="utf-8")
    metadata = {"source_records": len(rows), "sample_size": sample_size, "benign": counts["0"], "malicious": counts["1"], "seed": seed, "removed_columns": sorted(set(reader.fieldnames) - set(retained))}
    (output_dir / "subset_metadata.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    return metadata

def dirichlet_partition(labels: np.ndarray, devices: int, alpha: float, seed: int, minimum: int = 1) -> list[np.ndarray]:
    """Partition labels non-IID while ensuring a minimum device allocation."""
    labels = np.asarray(labels); rng = np.random.default_rng(seed)
    if devices * minimum > labels.size: raise ValueError("minimum allocation is infeasible")
    for _ in range(10_000):
        allocations = [[] for _ in range(devices)]
        for label in np.unique(labels):
            indices = np.flatnonzero(labels == label); rng.shuffle(indices)
            proportions = rng.dirichlet(np.full(devices, alpha))
            cuts = (np.cumsum(proportions)[:-1] * len(indices)).astype(int)
            for device, part in enumerate(np.split(indices, cuts)): allocations[device].extend(part.tolist())
        if min(map(len, allocations)) >= minimum:
            return [np.asarray(sorted(part), dtype=int) for part in allocations]
    raise RuntimeError("could not satisfy minimum allocation; adjust alpha or minimum")

def qpca_inspired_rank(pca_scores: np.ndarray, components: int = 4) -> np.ndarray:
    """Classical eigenvalue/variance ranking; this is not genuine quantum PCA."""
    variances = np.var(np.asarray(pca_scores, dtype=float), axis=0, ddof=1)
    return np.argsort(variances)[::-1][:components]
