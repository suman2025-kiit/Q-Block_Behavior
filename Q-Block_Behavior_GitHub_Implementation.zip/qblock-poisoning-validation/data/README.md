# Dataset location

Place the public TON_IoT `Train_Test_Network.csv` file in this directory. The
CSV is excluded from Git because its license and size should be handled by the
dataset provider. Run the preparation command documented in the main README.
