const { expect } = require("chai");
const { ethers } = require("hardhat");
describe("QBlockValidation", function () {
  it("accepts a signed artifact and rejects nonce replay", async function () {
    const [owner] = await ethers.getSigners();
    const Factory = await ethers.getContractFactory("QBlockValidation");
    const contract = await Factory.deploy();
    const artifact = ethers.id("artifact"), did = ethers.id("did:qblock:device:1"), vc = ethers.id("vc-1"), nonce = ethers.id("nonce-1");
    const expires = (await ethers.provider.getBlock("latest")).timestamp + 3600;
    const packed = ethers.solidityPackedKeccak256(["bytes32","bytes32","bytes32","bytes32","uint256"], [artifact,did,vc,nonce,expires]);
    const signature = await owner.signMessage(ethers.getBytes(packed));
    await expect(contract.validateArtifact(artifact,did,vc,nonce,expires,owner.address,signature)).to.emit(contract,"ArtifactValidated");
    await expect(contract.validateArtifact(artifact,did,vc,nonce,expires,owner.address,signature)).to.be.revertedWith("replayed nonce");
  });
});
