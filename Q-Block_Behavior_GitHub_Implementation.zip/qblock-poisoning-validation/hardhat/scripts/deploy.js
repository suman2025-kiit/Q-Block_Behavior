const { ethers } = require("hardhat");
async function main() { const Factory = await ethers.getContractFactory("QBlockValidation"); const contract = await Factory.deploy(); await contract.waitForDeployment(); console.log(await contract.getAddress()); }
main().catch((error) => { console.error(error); process.exitCode = 1; });
