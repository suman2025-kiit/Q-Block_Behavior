require("@nomicfoundation/hardhat-toolbox");
module.exports = {solidity: "0.8.24", networks: {hardhat: {chainId: 31337}}, paths: {sources: "../contracts"}};
